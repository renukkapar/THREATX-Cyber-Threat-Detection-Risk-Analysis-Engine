import ipaddress
import os
import socket

import requests


REQUEST_TIMEOUT = 12


# ---------------------------------------------------------
# ABUSEIPDB
# ---------------------------------------------------------

def abuseipdb_lookup(ip):

    api_key = os.getenv("ABUSEIPDB_API_KEY")

    if not api_key:
        return {
            "available": False,
            "message": "AbuseIPDB API key not configured."
        }

    try:

        response = requests.get(
            "https://api.abuseipdb.com/api/v2/check",
            headers={
                "Key": api_key,
                "Accept": "application/json"
            },
            params={
                "ipAddress": ip,
                "maxAgeInDays": 90
            },
            timeout=REQUEST_TIMEOUT
        )

        if response.status_code != 200:

            return {
                "available": False,
                "message": f"AbuseIPDB HTTP {response.status_code}"
            }

        data = response.json().get("data", {})

        return {
            "available": True,
            "abuse_confidence_score":
                data.get("abuseConfidenceScore", 0),
            "total_reports":
                data.get("totalReports", 0),
            "country":
                data.get("countryCode", ""),
            "isp":
                data.get("isp", ""),
            "domain":
                data.get("domain", ""),
            "is_public":
                data.get("isPublic", False),
            "last_reported_at":
                data.get("lastReportedAt", "")
        }

    except Exception as error:

        return {
            "available": False,
            "message": str(error)
        }


# ---------------------------------------------------------
# VIRUSTOTAL
# ---------------------------------------------------------

def virustotal_hash_lookup(file_hash):

    api_key = os.getenv("VIRUSTOTAL_API_KEY")

    if not api_key:

        return {
            "available": False,
            "message": "VirusTotal API key not configured."
        }

    try:

        response = requests.get(
            f"https://www.virustotal.com/api/v3/files/{file_hash}",
            headers={
                "x-apikey": api_key
            },
            timeout=REQUEST_TIMEOUT
        )

        if response.status_code == 404:

            return {
                "available": True,
                "found": False,
                "message": "Hash not found in VirusTotal."
            }

        if response.status_code != 200:

            return {
                "available": False,
                "message": f"VirusTotal HTTP {response.status_code}"
            }

        data = response.json()["data"]["attributes"]

        stats = data.get("last_analysis_stats", {})

        return {
            "available": True,
            "found": True,
            "malicious": stats.get("malicious", 0),
            "suspicious": stats.get("suspicious", 0),
            "harmless": stats.get("harmless", 0),
            "undetected": stats.get("undetected", 0),
            "total_engines":
                sum(stats.values()),
            "file_name":
                data.get("meaningful_name", ""),
            "type_description":
                data.get("type_description", ""),
            "size":
                data.get("size", 0)
        }

    except Exception as error:

        return {
            "available": False,
            "message": str(error)
        }


# ---------------------------------------------------------
# VIRUSTOTAL DOMAIN / IP SEARCH
# ---------------------------------------------------------

def virustotal_search(indicator):

    api_key = os.getenv("VIRUSTOTAL_API_KEY")

    if not api_key:

        return {
            "available": False,
            "message": "VirusTotal API key not configured."
        }

    try:

        response = requests.get(
            "https://www.virustotal.com/api/v3/search",
            headers={
                "x-apikey": api_key
            },
            params={
                "query": indicator
            },
            timeout=REQUEST_TIMEOUT
        )

        if response.status_code != 200:

            return {
                "available": False,
                "message": f"VirusTotal HTTP {response.status_code}"
            }

        data = response.json().get("data", [])

        return {
            "available": True,
            "found": len(data) > 0,
            "results": data[:5]
        }

    except Exception as error:

        return {
            "available": False,
            "message": str(error)
        }


# ---------------------------------------------------------
# DNS LOOKUP
# ---------------------------------------------------------

def dns_lookup(domain):

    try:

        addresses = socket.getaddrinfo(
            domain,
            None
        )

        ips = sorted({
            result[4][0]
            for result in addresses
        })

        return {
            "available": True,
            "resolved_ips": ips
        }

    except Exception as error:

        return {
            "available": False,
            "resolved_ips": [],
            "message": str(error)
        }


# ---------------------------------------------------------
# IP GEOLOCATION
# ---------------------------------------------------------

def ip_geolocation(ip):

    try:

        ipaddress.ip_address(ip)

        response = requests.get(
            f"https://ipapi.co/{ip}/json/",
            timeout=REQUEST_TIMEOUT
        )

        if response.status_code != 200:

            return {
                "available": False
            }

        data = response.json()

        return {
            "available": True,
            "country": data.get("country_name", ""),
            "country_code": data.get("country_code", ""),
            "city": data.get("city", ""),
            "region": data.get("region", ""),
            "organization": data.get("org", ""),
            "asn": data.get("asn", "")
        }

    except Exception as error:

        return {
            "available": False,
            "message": str(error)
        }


# ---------------------------------------------------------
# URL HEURISTICS
# ---------------------------------------------------------

def url_heuristic(url):

    parsed = None

    try:
        parsed = __import__("urllib.parse", fromlist=["urlparse"]).urlparse(url)
    except Exception:
        pass

    score = 0
    factors = []

    if not parsed:
        return {
            "score": 0,
            "factors": []
        }

    hostname = parsed.hostname or ""

    if parsed.scheme.lower() == "http":

        score += 10

        factors.append(
            "URL uses unencrypted HTTP."
        )

    suspicious_words = [
        "login",
        "verify",
        "secure",
        "account",
        "update",
        "password",
        "wallet",
        "bank",
        "confirm"
    ]

    lowered = url.lower()

    matched_words = [
        word
        for word in suspicious_words
        if word in lowered
    ]

    if matched_words:

        score += min(len(matched_words) * 5, 25)

        factors.append(
            "Suspicious keywords detected: "
            + ", ".join(matched_words)
        )

    if len(url) > 150:

        score += 10

        factors.append(
            "Unusually long URL."
        )

    if hostname.count(".") >= 4:

        score += 10

        factors.append(
            "High number of subdomains."
        )

    if "@" in url:

        score += 15

        factors.append(
            "URL contains @ symbol."
        )

    return {
        "score": min(score, 100),
        "factors": factors
    }


# ---------------------------------------------------------
# MAIN ENRICHMENT FUNCTION
# ---------------------------------------------------------

def enrich_indicator(indicator, ioc_type):

    result = {
        "sources": [],
        "confidence": 0,
        "malware": "",
        "country": "",
        "risk_evidence": {}
    }

    # IP
    if ioc_type == "IP":

        abuse = abuseipdb_lookup(indicator)

        result["risk_evidence"]["abuseipdb"] = abuse

        if abuse.get("available"):

            result["sources"].append("AbuseIPDB")

            result["confidence"] = abuse.get(
                "abuse_confidence_score",
                0
            )

            result["country"] = abuse.get(
                "country",
                ""
            )

        geo = ip_geolocation(indicator)

        result["risk_evidence"]["geolocation"] = geo

        if geo.get("available"):

            result["sources"].append(
                "IP Geolocation"
            )

            if not result["country"]:

                result["country"] = geo.get(
                    "country_code",
                    ""
                )

        vt = virustotal_search(indicator)

        result["risk_evidence"]["virustotal"] = vt

        if vt.get("available"):

            result["sources"].append(
                "VirusTotal"
            )

    # Domain
    elif ioc_type == "DOMAIN":

        dns = dns_lookup(indicator)

        result["risk_evidence"]["dns"] = dns

        if dns.get("available"):

            result["sources"].append("DNS")

        vt = virustotal_search(indicator)

        result["risk_evidence"]["virustotal"] = vt

        if vt.get("available"):

            result["sources"].append(
                "VirusTotal"
            )

        try:

            rdap_response = requests.get(
                f"https://rdap.org/domain/{indicator}",
                timeout=REQUEST_TIMEOUT
            )

            if rdap_response.status_code == 200:

                result["risk_evidence"]["rdap"] = {
                    "available": True,
                    "data": rdap_response.json()
                }

                result["sources"].append(
                    "RDAP"
                )

        except Exception as error:

            result["risk_evidence"]["rdap"] = {
                "available": False,
                "message": str(error)
            }

    # URL
    elif ioc_type == "URL":

        heuristic = url_heuristic(indicator)

        result["risk_evidence"]["url_heuristic"] = heuristic

        result["sources"].append(
            "THREATX URL Heuristics"
        )

        try:

            parsed = __import__(
                "urllib.parse",
                fromlist=["urlparse"]
            ).urlparse(indicator)

            hostname = parsed.hostname

            if hostname:

                dns = dns_lookup(hostname)

                result["risk_evidence"]["dns"] = dns

                if dns.get("available"):

                    result["sources"].append(
                        "DNS"
                    )

        except Exception:
            pass

    # Hash
    elif ioc_type in ["MD5", "SHA1", "SHA256"]:

        vt = virustotal_hash_lookup(
            indicator
        )

        result["risk_evidence"]["virustotal"] = vt

        if vt.get("available"):

            result["sources"].append(
                "VirusTotal"
            )

            if vt.get("found"):

                result["malware"] = vt.get(
                    "file_name",
                    ""
                )

    result["sources"] = list(
        dict.fromkeys(result["sources"])
    )

    return result