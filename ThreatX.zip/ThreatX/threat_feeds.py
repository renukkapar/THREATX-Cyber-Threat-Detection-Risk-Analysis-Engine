import csv
import io
import os
from datetime import datetime, timezone

import requests

TIMEOUT = 20

# Public abuse.ch feeds. URLs can be overridden in .env.
URLHAUS_TEXT_FEED = os.getenv(
    "URLHAUS_FEED_URL",
    "https://urlhaus.abuse.ch/downloads/text_recent/",
)
FEODO_TEXT_FEED = os.getenv(
    "FEODO_FEED_URL",
    "https://feodotracker.abuse.ch/downloads/ipblocklist.txt",
)
THREATFOX_API_URL = os.getenv(
    "THREATFOX_API_URL",
    "https://threatfox-api.abuse.ch/api/v1/",
)


def _get(url, headers=None):
    response = requests.get(url, headers=headers or {}, timeout=TIMEOUT)
    response.raise_for_status()
    return response.text


def parse_urlhaus(text, limit=200):
    indicators = []
    for line in text.splitlines():
        value = line.strip()
        if not value or value.startswith("#"):
            continue
        if value.startswith("http://") or value.startswith("https://"):
            indicators.append({
                "indicator": value,
                "type": "URL",
                "source": "URLhaus",
                "confidence": 90,
                "malware": "",
            })
        if len(indicators) >= limit:
            break
    return indicators


def parse_feodo(text, limit=200):
    indicators = []
    for line in text.splitlines():
        value = line.strip()
        if not value or value.startswith("#"):
            continue
        # Typical Feodo blocklist lines begin with an IPv4 address.
        candidate = value.split()[0]
        parts = candidate.split(".")
        if len(parts) == 4 and all(part.isdigit() for part in parts):
            indicators.append({
                "indicator": candidate,
                "type": "IP",
                "source": "Feodo Tracker",
                "confidence": 95,
                "malware": "",
            })
        if len(indicators) >= limit:
            break
    return indicators


def fetch_urlhaus(limit=200):
    try:
        return {
            "status": "ok",
            "feed": "URLhaus",
            "indicators": parse_urlhaus(_get(URLHAUS_TEXT_FEED), limit),
        }
    except Exception as exc:
        return {"status": "error", "feed": "URLhaus", "error": str(exc), "indicators": []}


def fetch_feodo(limit=200):
    try:
        return {
            "status": "ok",
            "feed": "Feodo Tracker",
            "indicators": parse_feodo(_get(FEODO_TEXT_FEED), limit),
        }
    except Exception as exc:
        return {"status": "error", "feed": "Feodo Tracker", "error": str(exc), "indicators": []}


def fetch_threatfox(limit=200):
    auth_key = os.getenv("THREATFOX_AUTH_KEY")
    if not auth_key:
        return {
            "status": "not_configured",
            "feed": "ThreatFox",
            "error": "Set THREATFOX_AUTH_KEY in .env.",
            "indicators": [],
        }

    try:
        response = requests.post(
            THREATFOX_API_URL,
            headers={"Auth-Key": auth_key, "Content-Type": "application/json"},
            json={"query": "get_iocs", "days": 3},
            timeout=TIMEOUT,
        )
        response.raise_for_status()
        data = response.json()

        output = []
        for item in data.get("data", [])[:limit]:
            ioc = item.get("ioc")
            ioc_type = item.get("ioc_type", "")
            mapped = {
                "ip": "IP",
                "domain": "DOMAIN",
                "url": "URL",
                "hash": "HASH",
                "md5_hash": "HASH",
                "sha1_hash": "HASH",
                "sha256_hash": "HASH",
            }.get(ioc_type, "UNKNOWN")

            if ioc and mapped != "UNKNOWN":
                output.append({
                    "indicator": ioc,
                    "type": mapped,
                    "source": "ThreatFox",
                    "confidence": int(item.get("confidence_level", 0) or 0),
                    "malware": item.get("malware_printable", "") or item.get("malware", "") or "",
                })

        return {"status": "ok", "feed": "ThreatFox", "indicators": output}
    except Exception as exc:
        return {"status": "error", "feed": "ThreatFox", "error": str(exc), "indicators": []}


def save_feed_indicators(indicators):
    from database import save_indicator

    for item in indicators:
        confidence = min(int(item.get("confidence", 0) or 0), 100)
        # Feed confidence is stored as confidence; feed ingestion itself does
        # not invent a score, so risk_score starts at 0 until enrichment.
        save_indicator(
            indicator=item["indicator"],
            ioc_type=item["type"],
            threat_level="PENDING ANALYSIS",
            risk_score=0,
            source=item["source"],
            confidence=confidence,
            malware=item.get("malware", ""),
        )


def sync_all_feeds(limit_per_feed=200):
    started = datetime.now(timezone.utc).isoformat()

    results = [
        fetch_urlhaus(limit_per_feed),
        fetch_threatfox(limit_per_feed),
        fetch_feodo(limit_per_feed),
    ]

    imported = 0
    for result in results:
        if result.get("status") == "ok":
            save_feed_indicators(result.get("indicators", []))
            imported += len(result.get("indicators", []))

    return {
        "started": started,
        "imported": imported,
        "feeds": [
            {
                "feed": item.get("feed"),
                "status": item.get("status"),
                "count": len(item.get("indicators", [])),
                "error": item.get("error", ""),
            }
            for item in results
        ],
    }
