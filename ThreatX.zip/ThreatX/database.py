import sqlite3
from datetime import datetime


DATABASE_NAME = "iocs.db"


# ---------------------------------------------------------
# DATABASE CONNECTION
# ---------------------------------------------------------

def get_connection():

    connection = sqlite3.connect(DATABASE_NAME)

    connection.row_factory = sqlite3.Row

    return connection


# ---------------------------------------------------------
# INITIALIZE DATABASE
# ---------------------------------------------------------

def init_db():

    connection = get_connection()

    cursor = connection.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS indicators (

            id INTEGER PRIMARY KEY AUTOINCREMENT,

            indicator TEXT NOT NULL,

            type TEXT NOT NULL,

            threat_level TEXT NOT NULL,

            risk_score INTEGER NOT NULL DEFAULT 0,

            source TEXT NOT NULL DEFAULT 'THREATX',

            confidence INTEGER NOT NULL DEFAULT 0,

            malware TEXT DEFAULT '',

            country TEXT DEFAULT '',

            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)

    connection.commit()

    # Safe migration for older databases
    cursor.execute("PRAGMA table_info(indicators)")

    columns = [
        row["name"]
        for row in cursor.fetchall()
    ]

    if "confidence" not in columns:

        cursor.execute("""
            ALTER TABLE indicators
            ADD COLUMN confidence INTEGER DEFAULT 0
        """)

    if "malware" not in columns:

        cursor.execute("""
            ALTER TABLE indicators
            ADD COLUMN malware TEXT DEFAULT ''
        """)

    if "country" not in columns:

        cursor.execute("""
            ALTER TABLE indicators
            ADD COLUMN country TEXT DEFAULT ''
        """)

    connection.commit()

    connection.close()


# ---------------------------------------------------------
# SAVE IOC
# ---------------------------------------------------------

def save_indicator(
    indicator,
    ioc_type,
    threat_level,
    risk_score,
    source="THREATX",
    confidence=0,
    malware="",
    country=""
):

    connection = get_connection()

    cursor = connection.cursor()

    cursor.execute("""
        INSERT INTO indicators (
            indicator,
            type,
            threat_level,
            risk_score,
            source,
            confidence,
            malware,
            country,
            timestamp
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        indicator,
        ioc_type,
        threat_level,
        risk_score,
        source,
        confidence,
        malware,
        country,
        datetime.utcnow()
    ))

    connection.commit()

    connection.close()


# ---------------------------------------------------------
# GET ALL INDICATORS
# ---------------------------------------------------------

def get_all_indicators(limit=50):

    connection = get_connection()

    cursor = connection.cursor()

    cursor.execute("""
        SELECT
            id,
            indicator,
            type,
            threat_level,
            risk_score,
            source,
            confidence,
            malware,
            country,
            timestamp
        FROM indicators
        ORDER BY id DESC
        LIMIT ?
    """, (limit,))

    rows = cursor.fetchall()

    connection.close()

    return [dict(row) for row in rows]


# ---------------------------------------------------------
# SEARCH IOC HISTORY
# ---------------------------------------------------------

def get_indicator_history(query):

    connection = get_connection()

    cursor = connection.cursor()

    search_term = f"%{query}%"

    cursor.execute("""
        SELECT
            id,
            indicator,
            type,
            threat_level,
            risk_score,
            source,
            confidence,
            malware,
            country,
            timestamp
        FROM indicators
        WHERE indicator LIKE ?
           OR type LIKE ?
           OR source LIKE ?
           OR malware LIKE ?
           OR country LIKE ?
        ORDER BY id DESC
        LIMIT 100
    """, (
        search_term,
        search_term,
        search_term,
        search_term,
        search_term
    ))

    rows = cursor.fetchall()

    connection.close()

    return [dict(row) for row in rows]


# ---------------------------------------------------------
# DASHBOARD STATISTICS
# ---------------------------------------------------------

def get_dashboard_stats():

    connection = get_connection()

    cursor = connection.cursor()

    cursor.execute("""
        SELECT COUNT(*) AS total
        FROM indicators
    """)

    total = cursor.fetchone()["total"]

    cursor.execute("""
        SELECT COUNT(*) AS count
        FROM indicators
        WHERE threat_level = 'LOW RISK'
    """)

    low = cursor.fetchone()["count"]

    cursor.execute("""
        SELECT COUNT(*) AS count
        FROM indicators
        WHERE threat_level = 'MEDIUM RISK'
    """)

    medium = cursor.fetchone()["count"]

    cursor.execute("""
        SELECT COUNT(*) AS count
        FROM indicators
        WHERE threat_level = 'HIGH RISK'
    """)

    high = cursor.fetchone()["count"]

    cursor.execute("""
        SELECT COUNT(*) AS count
        FROM indicators
        WHERE threat_level = 'CRITICAL RISK'
    """)

    critical = cursor.fetchone()["count"]

    cursor.execute("""
        SELECT
            source,
            COUNT(*) AS count
        FROM indicators
        GROUP BY source
        ORDER BY count DESC
    """)

    source_rows = cursor.fetchall()

    sources = [
        {
            "source": row["source"],
            "count": row["count"]
        }
        for row in source_rows
    ]

    connection.close()

    return {
        "total": total,
        "low": low,
        "medium": medium,
        "high": high,
        "critical": critical,
        "sources": sources
    }