def calculate_risk_score(
    abuse_score=0,
    total_reports=0,
    is_public=False
):

    score = 0

    # Abuse confidence
    score += min(
        float(abuse_score) * 0.7,
        70
    )

    # Report activity
    if total_reports >= 100:
        score += 15

    elif total_reports >= 50:
        score += 10

    elif total_reports >= 10:
        score += 5

    elif total_reports > 0:
        score += 2

    # Public IP exposure
    if is_public:
        score += 5

    return min(
        round(score),
        100
    )


# ---------------------------------------------------------
# THREAT LEVEL
# ---------------------------------------------------------

def get_threat_level(score):

    if score >= 90:
        return "CRITICAL RISK"

    if score >= 70:
        return "HIGH RISK"

    if score >= 30:
        return "MEDIUM RISK"

    return "LOW RISK"


# ---------------------------------------------------------
# RECOMMENDATIONS
# ---------------------------------------------------------

def get_recommendation(level):

    recommendations = {

        "CRITICAL RISK":
            "Immediately isolate affected systems, block the IOC, investigate related activity, and initiate incident response.",

        "HIGH RISK":
            "Block or monitor the IOC, investigate affected systems, and review associated network activity.",

        "MEDIUM RISK":
            "Perform additional investigation and monitor the IOC for suspicious activity.",

        "LOW RISK":
            "No immediate blocking action is required. Continue monitoring and validate the IOC with additional intelligence sources."
    }

    return recommendations.get(
        level,
        "Continue investigation."
    )


# ---------------------------------------------------------
# MAIN SCORING ENGINE
# ---------------------------------------------------------

def score_indicator(
    indicator,
    ioc_type,
    enrichment
):

    candidates = []

    risk_factors = []

    evidence = enrichment.get(
        "risk_evidence",
        {}
    )

    # -----------------------------------------------------
    # AbuseIPDB
    # -----------------------------------------------------

    abuse = evidence.get(
        "abuseipdb",
        {}
    )

    if abuse.get("available"):

        abuse_score = abuse.get(
            "abuse_confidence_score",
            0
        )

        total_reports = abuse.get(
            "total_reports",
            0
        )

        is_public = abuse.get(
            "is_public",
            False
        )

        score = calculate_risk_score(
            abuse_score,
            total_reports,
            is_public
        )

        candidates.append(score)

        if abuse_score > 0:

            risk_factors.append(
                f"AbuseIPDB confidence score: {abuse_score}%"
            )

        if total_reports > 0:

            risk_factors.append(
                f"AbuseIPDB reports: {total_reports}"
            )

        if is_public:

            risk_factors.append(
                "Indicator is publicly exposed."
            )

    # -----------------------------------------------------
    # VirusTotal
    # -----------------------------------------------------

    vt = evidence.get(
        "virustotal",
        {}
    )

    if vt.get("available") and vt.get("found"):

        malicious = vt.get(
            "malicious",
            0
        )

        suspicious = vt.get(
            "suspicious",
            0
        )

        total = vt.get(
            "total_engines",
            0
        )

        if total > 0:

            vt_score = round(
                (
                    malicious
                    + suspicious * 0.5
                )
                / total
                * 100
            )

            candidates.append(
                vt_score
            )

            if malicious > 0:

                risk_factors.append(
                    f"VirusTotal detected malicious: {malicious}"
                )

            if suspicious > 0:

                risk_factors.append(
                    f"VirusTotal suspicious detections: {suspicious}"
                )

    # -----------------------------------------------------
    # URL HEURISTICS
    # -----------------------------------------------------

    url_data = evidence.get(
        "url_heuristic",
        {}
    )

    if url_data:

        url_score = url_data.get(
            "score",
            0
        )

        if url_score > 0:

            candidates.append(
                url_score
            )

            risk_factors.extend(
                url_data.get(
                    "factors",
                    []
                )
            )

    # -----------------------------------------------------
    # FINAL SCORE
    # -----------------------------------------------------

    if candidates:

        final_score = max(
            candidates
        )

    else:

        final_score = 0

    final_score = min(
        round(final_score),
        100
    )

    threat_level = get_threat_level(
        final_score
    )

    recommendation = get_recommendation(
        threat_level
    )

    if not risk_factors:

        risk_factors.append(
            "No strong malicious indicators were identified by the configured intelligence sources."
        )

    return {
        "risk_score": final_score,
        "threat_level": threat_level,
        "risk_factors": risk_factors,
        "recommendation": recommendation
    }