import csv
import io
import ipaddress
import os
import re
import socket
from urllib.parse import urlparse

from dotenv import load_dotenv
from flask import Flask, Response, jsonify, render_template, request

from database import (
    get_all_indicators,
    get_dashboard_stats,
    get_indicator_history,
    init_db,
    save_indicator,
)
from enrichment import enrich_indicator
from scoring import score_indicator
from threat_feeds import sync_all_feeds


load_dotenv()

app = Flask(__name__)

init_db()


# ---------------------------------------------------------
# IOC TYPE DETECTION
# ---------------------------------------------------------

def detect_ioc_type(indicator):
    indicator = indicator.strip()

    try:
        ipaddress.ip_address(indicator)
        return "IP"
    except ValueError:
        pass

    if re.fullmatch(r"[a-fA-F0-9]{32}", indicator):
        return "MD5"

    if re.fullmatch(r"[a-fA-F0-9]{40}", indicator):
        return "SHA1"

    if re.fullmatch(r"[a-fA-F0-9]{64}", indicator):
        return "SHA256"

    if indicator.lower().startswith(("http://", "https://")):
        return "URL"

    domain_pattern = (
        r"^(?=.{1,253}$)"
        r"(?:[a-zA-Z0-9]"
        r"(?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+"
        r"[a-zA-Z]{2,63}$"
    )

    if re.fullmatch(domain_pattern, indicator):
        return "DOMAIN"

    return "UNKNOWN"


# ---------------------------------------------------------
# HOME PAGE
# ---------------------------------------------------------

@app.route("/")
def index():
    return render_template("index.html")


# ---------------------------------------------------------
# DASHBOARD
# ---------------------------------------------------------

@app.route("/dashboard")
def dashboard():
    return render_template("dashboard.html")


# ---------------------------------------------------------
# SEARCH
# ---------------------------------------------------------

@app.route("/search")
def search():
    return render_template("search.html")


# ---------------------------------------------------------
# THREAT FEEDS
# ---------------------------------------------------------

@app.route("/feeds")
def feeds():
    return render_template("feeds.html")


# ---------------------------------------------------------
# ANALYZE IOC
# ---------------------------------------------------------

@app.route("/api/analyze", methods=["POST"])
def analyze():

    data = request.get_json(silent=True) or {}

    indicator = data.get("indicator", "").strip()

    if not indicator:
        return jsonify({
            "success": False,
            "error": "Please enter an IOC."
        }), 400

    ioc_type = detect_ioc_type(indicator)

    if ioc_type == "UNKNOWN":
        return jsonify({
            "success": False,
            "error": "Unsupported IOC format. Enter an IP, domain, URL, or file hash."
        }), 400

    enrichment = enrich_indicator(indicator, ioc_type)

    scoring = score_indicator(
        indicator,
        ioc_type,
        enrichment
    )

    risk_score = scoring.get("risk_score", 0)
    threat_level = scoring.get("threat_level", "LOW RISK")
    risk_factors = scoring.get("risk_factors", [])
    recommendation = scoring.get("recommendation", "")

    confidence = enrichment.get("confidence", 0)
    malware = enrichment.get("malware", "")
    country = enrichment.get("country", "")

    save_indicator(
        indicator=indicator,
        ioc_type=ioc_type,
        threat_level=threat_level,
        risk_score=risk_score,
        source="THREATX",
        confidence=confidence,
        malware=malware,
        country=country
    )

    if risk_score >= 70:
        print(
            f"[ALERT] {threat_level}: "
            f"{indicator} | Score: {risk_score}"
        )

    return jsonify({
        "success": True,
        "indicator": indicator,
        "type": ioc_type,
        "risk_score": risk_score,
        "threat_level": threat_level,
        "risk_factors": risk_factors,
        "recommendation": recommendation,
        "enrichment": enrichment
    })


# ---------------------------------------------------------
# SEARCH API
# ---------------------------------------------------------

@app.route("/api/search")
def api_search():

    query = request.args.get("q", "").strip()

    if not query:
        return jsonify({"history": []})

    results = get_indicator_history(query)

    return jsonify({"history": results})


# ---------------------------------------------------------
# HISTORY API
# ---------------------------------------------------------

@app.route("/api/history")
def api_history():

    results = get_all_indicators(100)

    return jsonify(results)


# ---------------------------------------------------------
# DASHBOARD API
# ---------------------------------------------------------

@app.route("/api/dashboard")
def api_dashboard():

    stats = get_dashboard_stats()

    return jsonify(stats)


# ---------------------------------------------------------
# FEED SYNC API
# ---------------------------------------------------------

@app.route("/api/feeds/sync", methods=["POST"])
def api_feed_sync():

    try:
        result = sync_all_feeds(limit_per_feed=200)

        return jsonify({
            "success": True,
            "imported": result.get("imported", 0),
            "feeds": result.get("feeds", []),
            "started": result.get("started")
        })

    except Exception as e:

        return jsonify({
            "success": False,
            "error": str(e)
        }), 500


# ---------------------------------------------------------
# FEED STATUS API
# ---------------------------------------------------------

@app.route("/api/feeds/status")
def api_feed_status():

    return jsonify({
        "success": True,
        "feeds": [
            {
                "name": "URLhaus",
                "type": "Malicious URLs",
                "status": "configured"
            },
            {
                "name": "Feodo Tracker",
                "type": "Botnet C2 IPs",
                "status": "configured"
            },
            {
                "name": "ThreatFox",
                "type": "Malware IOCs",
                "status": (
                    "configured"
                    if os.getenv("THREATFOX_AUTH_KEY")
                    else "not_configured"
                )
            }
        ]
    })


# ---------------------------------------------------------
# EXPORT API
# ---------------------------------------------------------

@app.route("/api/export")
def api_export():

    export_format = request.args.get("format", "csv").lower()

    records = get_all_indicators(10000)

    if export_format == "json":

        return Response(
            __import__("json").dumps(
                records,
                indent=2,
                default=str
            ),
            mimetype="application/json",
            headers={
                "Content-Disposition":
                    "attachment; filename=threatx_iocs.json"
            }
        )

    output = io.StringIO()

    if records:

        fieldnames = records[0].keys()

        writer = csv.DictWriter(
            output,
            fieldnames=fieldnames
        )

        writer.writeheader()
        writer.writerows(records)

    return Response(
        output.getvalue(),
        mimetype="text/csv",
        headers={
            "Content-Disposition":
                "attachment; filename=threatx_iocs.csv"
        }
    )


# ---------------------------------------------------------
# HEALTH CHECK
# ---------------------------------------------------------

@app.route("/api/health")
def health():

    return jsonify({
        "status": "ok",
        "application": "THREATX",
        "version": "1.0"
    })


# ---------------------------------------------------------
# RUN APPLICATION
# ---------------------------------------------------------

if __name__ == "__main__":

    print("=" * 60)
    print("THREATX - Cyber Threat Detection & Risk Analysis Engine")
    print("=" * 60)
    print("Server: http://127.0.0.1:5000")
    print("=" * 60)

    app.run(
        host="127.0.0.1",
        port=5000,
        debug=True
    )